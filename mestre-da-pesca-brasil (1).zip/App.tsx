
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  PlayerState, 
  GameStatus, 
  CaughtFish, 
  Fish, 
  Rarity, 
  Location, 
  GameItem 
} from './types';
import { FISH_LIST, LOCATIONS, SHOP_ITEMS, RARITY_COLORS } from './constants';
import { audioService } from './services/audioService';

const IconMoney = () => <span className="text-yellow-500 font-bold">R$</span>;

const App: React.FC = () => {
  const [player, setPlayer] = useState<PlayerState>(() => {
    const saved = localStorage.getItem('fishing_game_state');
    if (saved) return JSON.parse(saved);
    return {
      money: 100,
      xp: 0,
      level: 1,
      inventory: [],
      locationId: 'loc1',
      unlockedLocations: ['loc1'],
      purchasedItems: ['rod1', 'line1', 'bait1', 'float1'],
      equippedRod: 'rod1',
      equippedLine: 'line1',
      equippedBait: 'bait1',
      equippedFloat: 'float1'
    };
  });

  const [status, setStatus] = useState<GameStatus>(GameStatus.MENU);
  const [activeView, setActiveView] = useState<'fishing' | 'shop' | 'inventory' | 'map'>('fishing');
  const [lastCaught, setLastCaught] = useState<CaughtFish | null>(null);
  const [isMuted, setIsMuted] = useState(audioService.isMuted());
  const [purchaseOverlay, setPurchaseOverlay] = useState<GameItem | null>(null);

  // Mini-game State
  const [miniGameHits, setMiniGameHits] = useState(0);
  const [needleAngle, setNeedleAngle] = useState(0);
  const [targetZones, setTargetZones] = useState<{ start: number, end: number }[]>([]);
  const [miniGameActive, setMiniGameActive] = useState(false);
  const requestRef = useRef<number>(null);
  const speedRef = useRef(3);

  useEffect(() => {
    localStorage.setItem('fishing_game_state', JSON.stringify(player));
  }, [player]);

  const xpToNextLevel = player.level * 200;
  const currentLocation = useMemo(() => 
    LOCATIONS.find(l => l.id === player.locationId) || LOCATIONS[0]
  , [player.locationId]);

  const addXP = useCallback((amount: number) => {
    setPlayer(prev => {
      let newXp = prev.xp + amount;
      let newLevel = prev.level;
      while (newXp >= newLevel * 200) {
        newXp -= newLevel * 200;
        newLevel++;
      }
      return { ...prev, xp: newXp, level: newLevel };
    });
  }, []);

  const sellFish = (fishId: string) => {
    audioService.playClick();
    const fishToSell = player.inventory.find(f => f.id === fishId);
    if (!fishToSell) return;
    setPlayer(prev => ({
      ...prev,
      money: prev.money + fishToSell.price,
      inventory: prev.inventory.filter(f => f.id !== fishId)
    }));
  };

  const sellAll = () => {
    audioService.playClick();
    const total = player.inventory.reduce((sum, f) => sum + f.price, 0);
    setPlayer(prev => ({
      ...prev,
      money: prev.money + total,
      inventory: []
    }));
  };

  const castLine = () => {
    if (status !== GameStatus.IDLE) return;
    audioService.playCast();
    setStatus(GameStatus.CASTING);
    setTimeout(() => {
      setStatus(GameStatus.WAITING);
      const baitMultiplier = SHOP_ITEMS.find(i => i.id === player.equippedBait)?.multiplier || 1;
      const floatMultiplier = SHOP_ITEMS.find(i => i.id === player.equippedFloat)?.multiplier || 1;
      const totalBiteMultiplier = baitMultiplier * floatMultiplier;
      const waitTime = (Math.random() * 3000 + 2000) / totalBiteMultiplier;
      setTimeout(() => {
        setStatus(GameStatus.BITE);
        audioService.playBite();
      }, waitTime);
    }, 1000);
  };

  const generateTargetZones = () => {
    const zones = [];
    const count = 3; // 3 segments
    const zoneWidth = 50; // Increased to 50 for better usability
    for (let i = 0; i < count; i++) {
      const start = (i * (360 / count)) + Math.random() * 40;
      zones.push({ start, end: start + zoneWidth });
    }
    setTargetZones(zones);
  };

  const startMiniGame = (e?: React.MouseEvent | React.TouchEvent) => {
    if (e) e.stopPropagation();
    if (status !== GameStatus.BITE) return;
    setStatus(GameStatus.MINIGAME);
    setMiniGameHits(0);
    setNeedleAngle(0);
    setMiniGameActive(true);
    speedRef.current = 2.5 + (player.level * 0.1);
    generateTargetZones();
  };

  const animateNeedle = useCallback(() => {
    if (status === GameStatus.MINIGAME && miniGameActive) {
      setNeedleAngle(prev => (prev + speedRef.current) % 360);
      requestRef.current = requestAnimationFrame(animateNeedle);
    }
  }, [status, miniGameActive]);

  useEffect(() => {
    if (status === GameStatus.MINIGAME) {
      requestRef.current = requestAnimationFrame(animateNeedle);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [status, animateNeedle]);

  const handleMiniGameTap = (e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    if (status !== GameStatus.MINIGAME) return;

    const angle = needleAngle % 360;
    const isHit = targetZones.some(zone => {
      return angle >= zone.start && angle <= zone.end;
    });

    if (isHit) {
      audioService.playClick();
      const nextHits = miniGameHits + 1;
      setMiniGameHits(nextHits);
      speedRef.current += 0.8; // Increase speed on each hit
      generateTargetZones(); // Move zones

      if (nextHits >= 3) {
        setMiniGameActive(false);
        finishFishing(true);
      }
    } else {
      audioService.playFail();
      setMiniGameActive(false);
      finishFishing(false);
    }
  };

  const finishFishing = (success: boolean) => {
    if (success) {
      audioService.playSuccess();
      const possibleFishIds = currentLocation.fishIds;
      const possibleFish = FISH_LIST.filter(f => possibleFishIds.includes(f.id));
      const rodMulti = SHOP_ITEMS.find(i => i.id === player.equippedRod)?.multiplier || 1;
      const rand = Math.random() * 100;
      let rarity: Rarity = 'Comum';
      if (rand < 5 * rodMulti + player.level * 0.5) rarity = 'Lendário';
      else if (rand < 15 * rodMulti + player.level) rarity = 'Épico';
      else if (rand < 40 * rodMulti + player.level * 2) rarity = 'Raro';
      const filtered = possibleFish.filter(f => f.rarity === rarity);
      const chosen = filtered.length > 0 ? filtered[Math.floor(Math.random() * filtered.length)] : possibleFish[0];
      const weight = +(Math.random() * (chosen.maxWeight - chosen.minWeight) + chosen.minWeight).toFixed(2);
      const price = Math.floor(chosen.basePrice * (weight / chosen.minWeight));
      const newFish: CaughtFish = {
        id: Math.random().toString(36).substr(2, 9),
        fishId: chosen.id,
        name: chosen.name,
        rarity: chosen.rarity,
        weight,
        price,
        timestamp: Date.now()
      };
      setLastCaught(newFish);
      setPlayer(prev => ({ ...prev, inventory: [newFish, ...prev.inventory] }));
      addXP(Math.floor(price / 2) + 10);
      setStatus(GameStatus.RESULT);
    } else {
      setStatus(GameStatus.IDLE);
    }
  };

  const MainMenuView = () => (
    <div className="fixed inset-0 z-[100] bg-gradient-to-b from-blue-500 to-blue-900 flex flex-col items-center justify-center p-6 text-white text-center">
      <div className="mb-12 animate-bounce">
        <h1 className="text-5xl font-black drop-shadow-lg tracking-tighter">MESTRE DA PESCA</h1>
        <p className="text-xl font-bold opacity-80">Edição Brasil 🇧🇷</p>
      </div>
      <div className="w-full max-w-xs space-y-4">
        <button 
          onClick={() => { audioService.playClick(); setStatus(GameStatus.IDLE); }}
          className="w-full bg-yellow-400 hover:bg-yellow-300 text-blue-900 font-black py-4 rounded-3xl text-2xl shadow-[0_6px_0_rgba(180,140,0,1)] active:translate-y-1 active:shadow-none transition-all"
        >
          JOGAR
        </button>
        <button 
          onClick={() => { audioService.playClick(); setStatus(GameStatus.SETTINGS); }}
          className="w-full bg-white/20 hover:bg-white/30 text-white font-black py-4 rounded-3xl text-xl transition-all"
        >
          CONFIGURAÇÕES
        </button>
        <button 
          onClick={() => { audioService.playClick(); setStatus(GameStatus.EXIT); }}
          className="w-full bg-red-500/80 hover:bg-red-500 text-white font-black py-4 rounded-3xl text-xl transition-all"
        >
          SAIR
        </button>
      </div>
      <p className="absolute bottom-8 text-sm opacity-50">v2.1 • Edição Profissional</p>
    </div>
  );

  const SettingsView = () => (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-white text-center">
      <h2 className="text-3xl font-black mb-8 text-blue-400">CONFIGURAÇÕES</h2>
      <div className="w-full max-w-xs bg-white/10 p-6 rounded-3xl space-y-6">
        <div className="flex justify-between items-center">
          <span className="font-bold text-lg">Efeitos Sonoros</span>
          <button 
            onClick={() => setIsMuted(audioService.toggleMute())}
            className={`w-16 h-8 rounded-full transition-colors relative ${!isMuted ? 'bg-green-500' : 'bg-red-500'}`}
          >
            <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${!isMuted ? 'right-1' : 'left-1'}`}></div>
          </button>
        </div>
        <div className="flex justify-between items-center opacity-50">
          <span className="font-bold text-lg">Música</span>
          <span className="text-sm italic">(Em breve)</span>
        </div>
      </div>
      <button 
        onClick={() => { audioService.playClick(); setStatus(GameStatus.MENU); }}
        className="mt-8 bg-blue-600 hover:bg-blue-500 px-12 py-4 rounded-2xl font-black shadow-lg transition-all"
      >
        VOLTAR
      </button>
    </div>
  );

  const ExitView = () => (
    <div className="fixed inset-0 z-[100] bg-blue-900 flex flex-col items-center justify-center p-6 text-white text-center">
      <h2 className="text-4xl font-black mb-4">ATÉ LOGO!</h2>
      <p className="text-lg opacity-70 mb-8">Pesque muitos peixes da próxima vez!</p>
      <button 
        onClick={() => { audioService.playClick(); setStatus(GameStatus.MENU); }}
        className="bg-white text-blue-900 px-8 py-3 rounded-2xl font-black"
      >
        VOLTAR AO MENU
      </button>
    </div>
  );

  const FishingView = () => {
    return (
      <div 
        className={`flex-1 flex flex-col items-center justify-center relative overflow-hidden transition-colors duration-1000 ${currentLocation.bgClass}`}
        onClick={status === GameStatus.BITE ? (e) => startMiniGame(e) : undefined}
      >
        {/* Stylized 2D Environment */}
        <div className="absolute inset-0 pointer-events-none opacity-40">
           <div className="absolute top-10 left-1/4 w-24 h-8 bg-white/50 rounded-full blur-xl"></div>
           <div className="absolute top-20 right-1/4 w-32 h-10 bg-white/40 rounded-full blur-2xl"></div>
        </div>

        {/* 2D Stylized Water Layer */}
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-blue-600/60 border-t-8 border-white/20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle,white_2px,transparent_2px)] bg-[length:24px_24px] animate-pulse"></div>
          
          {status === GameStatus.WAITING && (
             <div className="absolute left-1/2 top-6 -translate-x-1/2">
               <div className="ripple scale-75"></div>
               <div className="w-6 h-6 bg-red-500 rounded-full border-2 border-white shadow-lg animate-bounce"></div>
             </div>
          )}
          {status === GameStatus.BITE && (
             <div className="absolute left-1/2 top-6 -translate-x-1/2 cursor-pointer">
               <div className="ripple border-white/40"></div>
               <div className="w-10 h-10 bg-red-600 rounded-full border-4 border-white shadow-2xl animate-ping"></div>
               <p className="text-white font-black absolute -top-16 left-1/2 -translate-x-1/2 bg-red-600 px-6 py-2 rounded-full shadow-2xl whitespace-nowrap animate-bounce scale-110 border-2 border-white/20">PUXA! 🎣</p>
             </div>
          )}
        </div>

        {status === GameStatus.IDLE && (
          <button onClick={castLine} className="z-10 bg-blue-600 hover:bg-blue-700 text-white px-12 py-6 rounded-full font-black text-2xl shadow-[0_8px_0_rgba(30,58,138,1)] active:translate-y-1 active:shadow-none transition-all transform hover:scale-105 border-4 border-blue-400/30">LANÇAR ISCA 🎣</button>
        )}

        {status === GameStatus.CASTING && (
          <div className="z-10 text-9xl animate-pulse filter drop-shadow-2xl">🎣</div>
        )}

        {status === GameStatus.MINIGAME && (
          <div 
            className="z-50 fixed inset-0 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm touch-none"
            onClick={handleMiniGameTap}
          >
            <div className="bg-white p-10 rounded-[4rem] w-full max-w-sm flex flex-col items-center gap-10 shadow-[0_0_80px_rgba(0,0,0,0.3)] border-8 border-blue-50 animate-in zoom-in duration-200">
              <div className="text-center">
                <h3 className="text-4xl font-black text-blue-900 mb-4 tracking-tight">FISGADA!</h3>
                <div className="flex justify-center gap-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className={`w-10 h-10 rounded-full border-4 transition-all duration-500 ${miniGameHits >= i ? 'bg-yellow-400 border-yellow-200 scale-125 shadow-xl rotate-12' : 'bg-gray-100 border-gray-50 opacity-40'}`}>
                      {miniGameHits >= i && <div className="w-full h-full flex items-center justify-center text-blue-900 text-xl font-black">★</div>}
                    </div>
                  ))}
                </div>
              </div>

              {/* Circular Mini-game UI Stylized */}
              <div className="relative w-72 h-72 rounded-full border-[12px] border-slate-900 bg-white shadow-2xl flex items-center justify-center overflow-hidden">
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                  {targetZones.map((zone, idx) => {
                    const radius = 110;
                    const circumference = 2 * Math.PI * radius;
                    const angleSize = zone.end - zone.start;
                    const strokeDasharray = `${(angleSize / 360) * circumference} ${circumference}`;
                    const strokeDashoffset = - (zone.start / 360) * circumference;
                    return (
                      <circle
                        key={idx}
                        cx="50%"
                        cy="50%"
                        r={radius}
                        fill="none"
                        stroke="#3b82f6" // Changed from green to vibrant blue
                        strokeWidth="32"
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        className="transition-all duration-300 drop-shadow-sm"
                      />
                    );
                  })}
                </svg>

                {/* Rotating Needle */}
                <div 
                  className="absolute w-2 h-36 bg-red-600 left-1/2 bottom-1/2 origin-bottom transition-none z-10 rounded-full shadow-lg"
                  style={{ transform: `translateX(-50%) rotate(${needleAngle}deg)` }}
                >
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-red-600 rounded-full border-4 border-white"></div>
                </div>

                <div className="w-12 h-12 bg-slate-900 rounded-full z-20 shadow-xl flex items-center justify-center border-4 border-slate-700">
                   <div className="w-3 h-3 bg-white rounded-full opacity-30"></div>
                </div>

                <div className="absolute inset-0 border-[20px] border-black/5 rounded-full pointer-events-none"></div>
              </div>

              <p className="text-xl font-black text-blue-600 uppercase tracking-widest animate-pulse">ACERTE O AZUL!</p>
            </div>
          </div>
        )}

        {status === GameStatus.RESULT && lastCaught && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <div className="bg-white rounded-[4rem] p-12 w-full max-w-sm flex flex-col items-center gap-6 text-center shadow-2xl animate-in zoom-in-95 duration-300 border-[10px] border-blue-100">
              <div className="text-9xl mb-6 drop-shadow-xl animate-bounce">{lastCaught.icon || '🐟'}</div>
              <h2 className="text-5xl font-black text-blue-900 leading-none tracking-tighter uppercase italic transform -rotate-2">INCRÍVEL!</h2>
              <div className="space-y-3">
                <p className="text-4xl font-black text-slate-800">{lastCaught.name}</p>
                <div className="flex flex-col items-center gap-2">
                  <span className={`px-6 py-2 rounded-full text-lg font-black inline-block shadow-sm ${RARITY_COLORS[lastCaught.rarity]}`}>
                    {lastCaught.rarity}
                  </span>
                  <p className="text-slate-400 font-black text-2xl tracking-tighter">{lastCaught.weight}kg</p>
                </div>
                <div className="flex items-center justify-center gap-3 text-green-600 text-4xl font-black mt-6 bg-green-50 px-6 py-3 rounded-3xl border-2 border-green-100">
                  <IconMoney /> {lastCaught.price}
                </div>
              </div>
              <button 
                onClick={() => setStatus(GameStatus.IDLE)}
                className="w-full mt-8 bg-blue-600 hover:bg-blue-700 text-white py-6 rounded-[2rem] font-black text-2xl shadow-xl active:scale-95 transition-all transform hover:rotate-1"
              >
                PESCAR MAIS 🎣
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const InventoryView = () => (
    <div className="flex-1 overflow-y-auto p-6 bg-slate-50 pb-24 text-slate-900">
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-3xl font-black">Mochila</h2>
        {player.inventory.length > 0 && (
          <button onClick={sellAll} className="bg-green-600 text-white px-6 py-2 rounded-2xl font-black text-sm shadow-lg hover:bg-green-700 transition-colors">VENDER TUDO</button>
        )}
      </div>
      {player.inventory.length === 0 ? (
        <div className="h-96 flex flex-col items-center justify-center text-gray-400 gap-4 opacity-40">
          <span className="text-9xl">🧺</span>
          <p className="font-black text-xl">Nada pescado ainda...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {player.inventory.map(item => (
            <div key={item.id} className="bg-white p-5 rounded-[2.5rem] border-4 border-slate-50 flex items-center justify-between shadow-sm hover:shadow-md transition-all hover:scale-[1.01]">
              <div className="flex items-center gap-5">
                <span className="text-6xl drop-shadow-sm">{item.icon || '🐟'}</span>
                <div>
                  <h4 className="font-black text-slate-900 text-xl leading-tight">{item.name}</h4>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter mb-1">{item.weight}kg • <span className={RARITY_COLORS[item.rarity].split(' ')[0]}>{item.rarity}</span></p>
                  <p className="text-green-600 font-black text-2xl flex items-center gap-1"><IconMoney /> {item.price}</p>
                </div>
              </div>
              <button onClick={() => sellFish(item.id)} className="bg-white border-4 border-green-500 text-green-600 font-black px-5 py-3 rounded-3xl active:bg-green-50 transition shadow-sm hover:shadow-md">VENDER</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const ShopView = () => {
    const buyItem = (item: GameItem) => {
      if (player.money < item.price) { alert("Saldo insuficiente, pescador!"); return; }
      audioService.playPurchase();
      setPurchaseOverlay(item);
      setPlayer(prev => ({
        ...prev,
        money: prev.money - item.price,
        purchasedItems: [...prev.purchasedItems, item.id]
      }));
      setTimeout(() => setPurchaseOverlay(null), 2000);
    };

    const equipItem = (item: GameItem) => {
      audioService.playClick();
      setPlayer(prev => {
        const update: Partial<PlayerState> = {};
        if (item.category === 'Vara') update.equippedRod = item.id;
        if (item.category === 'Linha') update.equippedLine = item.id;
        if (item.category === 'Isca') update.equippedBait = item.id;
        if (item.category === 'Equipamento de Flutuação') update.equippedFloat = item.id;
        return { ...prev, ...update };
      });
    };

    return (
      <div className="flex-1 overflow-y-auto p-6 bg-slate-50 pb-24 text-slate-900">
        <h2 className="text-3xl font-black mb-8">Loja do Porto</h2>
        
        {purchaseOverlay && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-blue-600/95 animate-in fade-in duration-300 backdrop-blur-sm">
            <div className="text-white text-center animate-bounce">
              <span className="text-9xl mb-6 block drop-shadow-2xl">{purchaseOverlay.icon}</span>
              <h3 className="text-5xl font-black tracking-tighter">É SEU!</h3>
              <p className="text-2xl font-bold opacity-90 mt-2">{purchaseOverlay.name}</p>
            </div>
          </div>
        )}

        <div className="space-y-12">
          {['Vara', 'Linha', 'Isca', 'Equipamento de Flutuação', 'Barco', 'Carro', 'Casa'].map(cat => (
            <section key={cat}>
              <h3 className="text-lg font-black text-slate-400 uppercase tracking-[0.2em] mb-6 flex items-center gap-4">
                <span className="w-12 h-1.5 bg-blue-500/20 rounded-full"></span> {cat}s
              </h3>
              <div className="grid grid-cols-1 gap-6">
                {SHOP_ITEMS.filter(i => i.category === cat).map(item => {
                  const isOwned = player.purchasedItems.includes(item.id);
                  const isEquipped = [player.equippedRod, player.equippedLine, player.equippedBait, player.equippedFloat].includes(item.id);
                  const isLocked = player.level < item.unlockedLevel;

                  return (
                    <div key={item.id} className={`p-6 rounded-[3rem] border-4 transition-all duration-300 ${isEquipped ? 'border-blue-500 bg-white shadow-xl scale-[1.02]' : 'border-white bg-white/60 shadow-sm opacity-90'}`}>
                      <div className="flex items-center gap-6">
                        <span className="text-7xl bg-slate-50 p-6 rounded-[2rem] shadow-inner border border-white/50">{item.icon}</span>
                        <div className="flex-1">
                          <h4 className="font-black text-slate-900 text-2xl leading-none mb-2">{item.name}</h4>
                          <p className="text-sm font-medium text-slate-400 mb-5 leading-tight">{item.description}</p>
                          {isLocked ? (
                            <p className="text-red-500 font-black text-xs uppercase bg-red-50 px-4 py-2 rounded-full inline-block border border-red-100">Nível {item.unlockedLevel} Requerido</p>
                          ) : (
                            <div className="flex justify-between items-center mt-auto">
                              <span className="text-green-600 font-black text-2xl flex items-center gap-1.5"><IconMoney /> {item.price.toLocaleString()}</span>
                              {isOwned ? (
                                isEquipped ? (
                                  <span className="text-blue-600 font-black text-xs uppercase bg-blue-50 px-6 py-3 rounded-2xl border border-blue-100">Equipado</span>
                                ) : (
                                  ['Barco', 'Carro', 'Casa'].includes(item.category) ? (
                                    <span className="text-slate-400 font-black text-xs bg-slate-100 px-6 py-3 rounded-2xl">Adquirido</span>
                                  ) : (
                                    <button onClick={() => equipItem(item)} className="bg-blue-600 text-white px-8 py-3 rounded-2xl text-sm font-black shadow-lg hover:bg-blue-700 transition-all active:scale-95">EQUIPAR</button>
                                  )
                                )
                              ) : (
                                <button onClick={() => buyItem(item)} className="bg-green-600 text-white px-8 py-3 rounded-2xl text-sm font-black shadow-lg hover:bg-green-700 transition-all active:scale-95">COMPRAR</button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </div>
    );
  };

  const MapView = () => {
    const unlockMap = (loc: Location) => {
      if (player.money < loc.price) { alert("Saldo insuficiente!"); return; }
      audioService.playPurchase();
      setPlayer(prev => ({
        ...prev,
        money: prev.money - loc.price,
        unlockedLocations: [...prev.unlockedLocations, loc.id]
      }));
    };
    const travelTo = (id: string) => { audioService.playClick(); setPlayer(prev => ({ ...prev, locationId: id })); setActiveView('fishing'); setStatus(GameStatus.IDLE); };

    return (
      <div className="flex-1 overflow-y-auto p-6 bg-slate-50 pb-24 text-slate-900">
        <h2 className="text-3xl font-black mb-8 tracking-tighter">Mapa Nacional</h2>
        <div className="grid grid-cols-1 gap-8">
          {LOCATIONS.map(loc => {
            const isUnlocked = player.unlockedLocations.includes(loc.id);
            const isLevelMet = player.level >= loc.minLevel;
            const isCurrent = player.locationId === loc.id;

            return (
              <div key={loc.id} className={`p-8 rounded-[4rem] border-4 transition-all relative overflow-hidden ${isCurrent ? 'border-blue-500 bg-white shadow-2xl scale-105 z-10' : 'border-white bg-white/60 shadow-md opacity-80'}`}>
                <div className="flex justify-between items-center relative z-10">
                  <div>
                    <h4 className="text-3xl font-black text-slate-900 mb-1 leading-none">{loc.name}</h4>
                    <p className="text-sm font-bold text-slate-400 mb-6 uppercase tracking-widest">Nível: {loc.minLevel}</p>
                    <div className="flex gap-2">
                      {loc.fishIds.slice(0, 4).map(id => (
                        <div key={id} className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-slate-100">{FISH_LIST.find(f => f.id === id)?.icon || '🐟'}</div>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    {isUnlocked ? (
                      isCurrent ? <span className="text-blue-600 font-black uppercase text-xs bg-blue-50 px-6 py-4 rounded-full border border-blue-100">Atual</span> : <button onClick={() => travelTo(loc.id)} className="bg-blue-600 text-white px-10 py-5 rounded-[2rem] font-black shadow-lg hover:bg-blue-700 active:scale-95 transition-all">VIAJAR</button>
                    ) : (
                      <div className="flex flex-col items-end">
                        {!isLevelMet && <p className="text-xs text-red-500 font-black mb-4 bg-red-50 px-4 py-2 rounded-full uppercase border border-red-100 tracking-tighter">Bloqueado</p>}
                        <button disabled={!isLevelMet} onClick={() => unlockMap(loc)} className={`px-8 py-4 rounded-[2rem] font-black shadow-lg transition-all ${isLevelMet ? 'bg-green-600 text-white hover:bg-green-700 active:scale-95' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}>
                          {loc.price === 0 ? 'GRÁTIS' : `R$ ${loc.price.toLocaleString()}`}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  if (status === GameStatus.MENU) return <MainMenuView />;
  if (status === GameStatus.SETTINGS) return <SettingsView />;
  if (status === GameStatus.EXIT) return <ExitView />;

  return (
    <div className="h-screen w-full flex flex-col overflow-hidden max-w-md mx-auto shadow-2xl bg-white border-x border-slate-200 font-fredoka selection:bg-blue-100">
      <header className="bg-white px-6 py-6 border-b-2 border-slate-50 flex justify-between items-center shrink-0 z-40 shadow-sm">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-blue-600 rounded-[2rem] flex items-center justify-center text-white font-black text-4xl shadow-xl border-[6px] border-blue-400 transform -rotate-6 transition-all hover:rotate-0 hover:scale-105 duration-300">
            {player.level}
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Exp. Mestre</span>
            <div className="w-36 h-5 bg-slate-100 rounded-full overflow-hidden shadow-inner border-2 border-white relative">
              <div className="h-full bg-blue-500 transition-all duration-700 shadow-[0_0_20px_rgba(59,130,246,0.8)]" style={{ width: `${(player.xp / xpToNextLevel) * 100}%` }}></div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-3 bg-green-50 px-6 py-3 rounded-[1.5rem] border-4 border-white shadow-xl group transition-all hover:bg-green-100">
            <IconMoney />
            <span className="font-black text-green-700 text-2xl tracking-tighter">{player.money.toLocaleString()}</span>
          </div>
          <button onClick={() => { audioService.playClick(); setStatus(GameStatus.MENU); }} className="text-slate-300 font-black text-[11px] uppercase mt-3 hover:text-blue-500 transition-colors tracking-[0.2em]">Menu Principal</button>
        </div>
      </header>

      <main className="flex-1 flex flex-col overflow-hidden relative">
        {activeView === 'fishing' && <FishingView />}
        {activeView === 'inventory' && <InventoryView />}
        {activeView === 'shop' && <ShopView />}
        {activeView === 'map' && <MapView />}
      </main>

      <nav className="bg-white border-t-2 border-slate-50 h-28 shrink-0 flex items-center justify-around px-4 pb-safe z-50 shadow-[0_-20px_60px_rgba(0,0,0,0.1)] rounded-t-[4rem]">
        {[
          { id: 'map', icon: '🗺️', label: 'Mapa' },
          { id: 'shop', icon: '🛒', label: 'Loja' },
          { id: 'fishing', icon: '🎣', label: 'Pescar' },
          { id: 'inventory', icon: '🎒', label: 'Bolsa' }
        ].map(item => (
          <button
            key={item.id}
            onClick={() => { audioService.playClick(); setActiveView(item.id as any); setStatus(GameStatus.IDLE); }}
            className={`flex flex-col items-center justify-center flex-1 gap-2 transition-all duration-300 ${
              activeView === item.id ? 'text-blue-600 scale-125 -translate-y-4 font-black' : 'text-slate-300 grayscale opacity-60'
            }`}
          >
            <span className="text-4xl drop-shadow-lg">{item.icon}</span>
            <span className="text-[11px] font-black uppercase tracking-widest">{item.label}</span>
            {activeView === item.id && <div className="w-3 h-3 bg-blue-600 rounded-full animate-ping absolute -top-2 shadow-xl"></div>}
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
