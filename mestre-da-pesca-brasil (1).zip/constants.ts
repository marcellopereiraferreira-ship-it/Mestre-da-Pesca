
import { Fish, Location, GameItem } from './types';

export const FISH_LIST: Fish[] = [
  // Lagoa Inicial
  { id: 'f1', name: 'Lambari', rarity: 'Comum', minWeight: 0.1, maxWeight: 0.3, basePrice: 5, icon: '🐟' },
  { id: 'f2', name: 'Tilápia', rarity: 'Comum', minWeight: 0.5, maxWeight: 2.0, basePrice: 15, icon: '🐠' },
  { id: 'f3', name: 'Carpa Pequena', rarity: 'Comum', minWeight: 1.0, maxWeight: 3.5, basePrice: 30, icon: '🐡' },
  { id: 'f4', name: 'Bagre', rarity: 'Raro', minWeight: 2.0, maxWeight: 8.0, basePrice: 120, icon: '🦞' },
  { id: 'f11', name: 'Piranha', rarity: 'Comum', minWeight: 0.3, maxWeight: 1.5, basePrice: 25, icon: '🦈' },
  // Rio Profundo
  { id: 'f5', name: 'Tucunaré', rarity: 'Raro', minWeight: 3.0, maxWeight: 10.0, basePrice: 250, icon: '🐟' },
  { id: 'f12', name: 'Pacu', rarity: 'Raro', minWeight: 2.0, maxWeight: 15.0, basePrice: 180, icon: '🐡' },
  { id: 'f6', name: 'Dourado', rarity: 'Épico', minWeight: 5.0, maxWeight: 25.0, basePrice: 600, icon: '✨' },
  { id: 'f13', name: 'Traíra', rarity: 'Comum', minWeight: 0.5, maxWeight: 4.0, basePrice: 45, icon: '🐟' },
  { id: 'f7', name: 'Pintado', rarity: 'Épico', minWeight: 10.0, maxWeight: 40.0, basePrice: 1200, icon: '🦈' },
  // Amazônia
  { id: 'f14', name: 'Aruanã', rarity: 'Épico', minWeight: 2.0, maxWeight: 8.0, basePrice: 1500, icon: '🐉' },
  { id: 'f8', name: 'Pirarucu', rarity: 'Épico', minWeight: 50.0, maxWeight: 200.0, basePrice: 3500, icon: '🦖' },
  { id: 'f15', name: 'Arraia de Rio', rarity: 'Raro', minWeight: 5.0, maxWeight: 30.0, basePrice: 850, icon: '💠' },
  { id: 'f9', name: 'Jaú Gigante', rarity: 'Lendário', minWeight: 100.0, maxWeight: 250.0, basePrice: 8000, icon: '🔱' },
  { id: 'f10', name: 'Peixe Dourado Místico', rarity: 'Lendário', minWeight: 1.0, maxWeight: 5.0, basePrice: 25000, icon: '👑' },
];

export const LOCATIONS: Location[] = [
  { 
    id: 'loc1', 
    name: 'Lagoa da Vila', 
    minLevel: 1, 
    price: 0, 
    fishIds: ['f1', 'f2', 'f3', 'f4', 'f11'], 
    bgClass: 'bg-emerald-300'
  },
  { 
    id: 'loc2', 
    name: 'Rio de Janeiro', 
    minLevel: 5, 
    price: 1000, 
    fishIds: ['f2', 'f3', 'f4', 'f5', 'f6', 'f12', 'f13'], 
    bgClass: 'bg-blue-300'
  },
  { 
    id: 'loc3', 
    name: 'Pantanal Profundo', 
    minLevel: 10, 
    price: 5000, 
    fishIds: ['f4', 'f5', 'f6', 'f7', 'f12', 'f15'], 
    bgClass: 'bg-amber-300'
  },
  { 
    id: 'loc4', 
    name: 'Reserva Amazônica', 
    minLevel: 20, 
    price: 25000, 
    fishIds: ['f6', 'f7', 'f8', 'f9', 'f10', 'f14'], 
    bgClass: 'bg-green-400'
  },
];

export const SHOP_ITEMS: GameItem[] = [
  // Varas
  { id: 'rod1', name: 'Vara de Bambu', category: 'Vara', description: 'Simples, mas funcional.', price: 0, multiplier: 1, unlockedLevel: 1, icon: '🎋' },
  { id: 'rod2', name: 'Vara de Fibra', category: 'Vara', description: 'Melhor chance de peixes raros.', price: 500, multiplier: 1.5, unlockedLevel: 3, icon: '🎣' },
  { id: 'rod3', name: 'Vara Pro Carbono', category: 'Vara', description: 'Elite da pescaria.', price: 5000, multiplier: 3, unlockedLevel: 10, icon: '⚡' },
  // Linhas
  { id: 'line1', name: 'Linha de Nylon', category: 'Linha', description: 'Aguenta o básico.', price: 0, multiplier: 10, unlockedLevel: 1, icon: '🧵' },
  { id: 'line2', name: 'Linha Multifilamento', category: 'Linha', description: 'Aguenta peixes de até 50kg.', price: 1500, multiplier: 50, unlockedLevel: 5, icon: '🧬' },
  { id: 'line3', name: 'Linha de Aço', category: 'Linha', description: 'Aguenta qualquer monstro.', price: 10000, multiplier: 500, unlockedLevel: 15, icon: '🔗' },
  // Iscas
  { id: 'bait1', name: 'Minhoca do Quintal', category: 'Isca', description: 'Isca clássica.', price: 0, multiplier: 1, unlockedLevel: 1, icon: '🪱' },
  { id: 'bait2', name: 'Isca Artificial', category: 'Isca', description: 'Peixes mordem mais rápido.', price: 800, multiplier: 2, unlockedLevel: 4, icon: '🦐' },
  { id: 'bait3', name: 'Isca Premium de Ouro', category: 'Isca', description: 'Atrai peixes gigantes.', price: 15000, multiplier: 5, unlockedLevel: 18, icon: '💎' },
  // Equipamento de Flutuação
  { id: 'float1', name: 'Bóia de Cortiça', category: 'Equipamento de Flutuação', description: 'Aumenta levemente a taxa de mordida.', price: 0, multiplier: 1, unlockedLevel: 1, icon: '⚪' },
  { id: 'float2', name: 'Bóia Colorida', category: 'Equipamento de Flutuação', description: 'Peixes percebem a isca mais rápido.', price: 400, multiplier: 1.5, unlockedLevel: 2, icon: '🔴' },
  { id: 'float3', name: 'Bóia Luminosa LED', category: 'Equipamento de Flutuação', description: 'Atração visual intensa.', price: 2500, multiplier: 2.2, unlockedLevel: 7, icon: '💡' },
  { id: 'float4', name: 'Flutuador Sonar', category: 'Equipamento de Flutuação', description: 'Tecnologia de ponta para atrair peixes.', price: 12000, multiplier: 4.0, unlockedLevel: 14, icon: '📡' },
  // Carros
  { id: 'car1', name: 'Fusca de Pescador', category: 'Carro', description: 'O clássico inquebrável.', price: 5000, multiplier: 0, unlockedLevel: 1, icon: '🚗' },
  { id: 'car2', name: 'Saveiro Rebaixada', category: 'Carro', description: 'Estilo e espaço para tralha.', price: 15000, multiplier: 0, unlockedLevel: 5, icon: '🛻' },
  { id: 'car3', name: 'Hilux 4x4 Pro', category: 'Carro', description: 'Chega em qualquer lugar.', price: 85000, multiplier: 0, unlockedLevel: 12, icon: '🚙' },
  { id: 'car4', name: 'Brasília Amarela', category: 'Carro', description: 'Relíquia de colecionador.', price: 120000, multiplier: 0, unlockedLevel: 20, icon: '🚕' },
  // Casas
  { id: 'house1', name: 'Cabana Simples', category: 'Casa', description: 'Um teto perto da água.', price: 10000, multiplier: 0, unlockedLevel: 1, icon: '🏚️' },
  { id: 'house2', name: 'Sítio no Interior', category: 'Casa', description: 'Muita paz e silêncio.', price: 45000, multiplier: 0, unlockedLevel: 8, icon: '🏡' },
  { id: 'house3', name: 'Mansão Beira-Rio', category: 'Casa', description: 'Pesque da sua varanda.', price: 250000, multiplier: 0, unlockedLevel: 18, icon: '🏰' },
  { id: 'house4', name: 'Ilha Particular', category: 'Casa', description: 'O ápice da vida de pescador.', price: 1000000, multiplier: 0, unlockedLevel: 30, icon: '🏝️' },
  // Barcos
  { id: 'boat1', name: 'Canoa de Madeira', category: 'Barco', description: 'Acesso a áreas rasas.', price: 2000, multiplier: 0, unlockedLevel: 2, icon: '🛶' },
  { id: 'boat2', name: 'Barco de Alumínio', category: 'Barco', description: 'Motor de popa 15hp.', price: 12000, multiplier: 0, unlockedLevel: 7, icon: '🚤' },
  { id: 'boat3', name: 'Lancha de Pesca', category: 'Barco', description: 'Velocidade e conforto.', price: 95000, multiplier: 0, unlockedLevel: 15, icon: '🛥️' },
];

export const RARITY_COLORS: Record<string, string> = {
  'Comum': 'text-gray-600 bg-gray-100',
  'Raro': 'text-blue-600 bg-blue-100',
  'Épico': 'text-purple-600 bg-purple-100',
  'Lendário': 'text-orange-600 bg-orange-100 font-bold',
};
