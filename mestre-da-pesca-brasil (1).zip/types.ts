
export type Rarity = 'Comum' | 'Raro' | 'Épico' | 'Lendário';

export interface Fish {
  id: string;
  name: string;
  rarity: Rarity;
  minWeight: number;
  maxWeight: number;
  basePrice: number;
  icon: string;
}

export interface CaughtFish {
  id: string;
  fishId: string;
  name: string;
  rarity: Rarity;
  weight: number;
  price: number;
  timestamp: number;
}

export interface Location {
  id: string;
  name: string;
  minLevel: number;
  price: number;
  fishIds: string[];
  bgClass: string;
}

export interface GameItem {
  id: string;
  name: string;
  category: 'Vara' | 'Linha' | 'Isca' | 'Equipamento de Flutuação' | 'Barco' | 'Carro' | 'Casa';
  description: string;
  price: number;
  multiplier: number; // Chance de raro, resistência, etc.
  unlockedLevel: number;
  icon: string;
}

export interface PlayerState {
  money: number;
  xp: number;
  level: number;
  inventory: CaughtFish[];
  locationId: string;
  unlockedLocations: string[];
  purchasedItems: string[];
  equippedRod: string;
  equippedLine: string;
  equippedBait: string;
  equippedFloat: string;
}

export enum GameStatus {
  MENU = 'MENU',
  SETTINGS = 'SETTINGS',
  IDLE = 'IDLE',
  CASTING = 'CASTING',
  WAITING = 'WAITING',
  BITE = 'BITE',
  MINIGAME = 'MINIGAME',
  RESULT = 'RESULT',
  EXIT = 'EXIT'
}
