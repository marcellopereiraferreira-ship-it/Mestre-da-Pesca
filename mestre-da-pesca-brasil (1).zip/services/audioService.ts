
class AudioService {
  private static instance: AudioService;
  private muted: boolean = false;
  private context: AudioContext | null = null;

  private constructor() {
    // Lazy init context on first interaction
  }

  static getInstance() {
    if (!AudioService.instance) {
      AudioService.instance = new AudioService();
    }
    return AudioService.instance;
  }

  toggleMute() {
    this.muted = !this.muted;
    return this.muted;
  }

  isMuted() {
    return this.muted;
  }

  private init() {
    if (!this.context) {
      this.context = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.context.state === 'suspended') {
      this.context.resume();
    }
  }

  playClick() {
    this.playTone(440, 0.1, 'square');
  }

  playSuccess() {
    this.playTone(523, 0.1);
    setTimeout(() => this.playTone(659, 0.1), 100);
    setTimeout(() => this.playTone(784, 0.2), 200);
  }

  playPurchase() {
    this.playTone(880, 0.1, 'sine', 0.4);
    setTimeout(() => this.playTone(1046, 0.1, 'sine', 0.4), 80);
    setTimeout(() => this.playTone(1318, 0.2, 'sine', 0.4), 160);
  }

  playFail() {
    this.playTone(200, 0.3, 'sawtooth');
  }

  playBite() {
    this.playTone(880, 0.05);
    setTimeout(() => this.playTone(880, 0.05), 100);
  }

  playCast() {
    this.playTone(300, 0.2, 'sine', 0.2);
  }

  private playTone(freq: number, duration: number, type: OscillatorType = 'sine', volume = 0.3) {
    if (this.muted) return;
    this.init();
    if (!this.context) return;

    const osc = this.context.createOscillator();
    const gain = this.context.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.context.currentTime);
    osc.connect(gain);
    gain.connect(this.context.destination);

    gain.gain.setValueAtTime(volume, this.context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, this.context.currentTime + duration);

    osc.start();
    osc.stop(this.context.currentTime + duration);
  }
}

export const audioService = AudioService.getInstance();
